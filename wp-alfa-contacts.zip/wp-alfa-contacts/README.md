# README #

Teste commit, plugin wordpress

### What is this repository for? ###

* Projeto plugin crud
* v.0.1
* http://cleitonsilva.eu1.alfasoft.pt/

### How do I get set up? ###


* Wordpress
* Dependencies
* Database configuration
