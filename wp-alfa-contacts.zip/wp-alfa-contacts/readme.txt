=== WP Alfa Contacts ===
* Plugin Name: WP Alfa Contacts
* Description: Plugin test php alfa
* Version:     1.0
* Author:      Cleiton
* Author URI:  http://cleitonsilva.eu1.alfasoft.pt/
* License:     GPL2
* Text Domain: wpalfa

WP Alfa Contacts